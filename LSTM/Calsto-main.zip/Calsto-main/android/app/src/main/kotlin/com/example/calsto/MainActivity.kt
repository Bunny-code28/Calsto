package com.example.calsto

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
