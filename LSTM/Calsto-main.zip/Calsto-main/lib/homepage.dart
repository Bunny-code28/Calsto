import 'package:calsto/pages/graph.dart';
import 'package:calsto/pages/price.dart';
import 'package:calsto/pages/priceplus.dart';
import 'package:calsto/pages/resources.dart';
import 'package:calsto/pages/riskcal.dart';
import 'package:calsto/pages/riskcalplus.dart';
import 'package:flutter/material.dart';

class Home extends StatefulWidget {
  const Home({
    Key? key,
  }) : super(key: key);

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.black, // Color.fromARGB(255, 40, 49, 27),
        appBar: AppBar(
          backgroundColor: Colors.amber,
          title: const Text(
            "CALSTO",
            style: TextStyle(
                color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
          ),
          elevation: 0,
        ),
        drawer: Drawer(
          //backgroundColor: Colors.black,
          width: 220,
          child: ListView(
            children: [
              DrawerHeader(
                decoration: const BoxDecoration(color: Colors.amber),
                child: Stack(
                  children: <Widget>[
                    Align(
                      alignment: Alignment.topCenter,
                      child: Stack(
                        children: <Widget>[
                          ClipOval(
                            child: Image.asset(
                              'assets/images/calstobg.png',
                              width: 80,
                              height: 80,
                              fit: BoxFit.cover,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(
                      height: 10.0,
                    ),
                    const Align(
                      alignment: Alignment.bottomCenter,
                      child: Text(
                        'CALSTO',
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 18,
                            fontWeight: FontWeight.bold),
                        textAlign: TextAlign.end,
                      ),
                    ),
                    const SizedBox(
                      height: 20,
                    )
                  ],
                ),
              ),
              ListTile(
                leading: const Icon(Icons.menu),
                title: const Text(
                  'Resources',
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: (context) => const Resources(),
                  ));
                },
              ),
              ListTile(
                leading: const Icon(Icons.menu),
                title: const Text('RiskCal'),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: (context) => const RiskCal(),
                  ));
                },
              ),
              ListTile(
                leading: const Icon(Icons.menu),
                title: const Text('RiskCal+'),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: (context) => const RiskCalPlus(),
                  ));
                },
              ),
              ListTile(
                leading: const Icon(Icons.menu),
                title: const Text('Price'),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: (context) => const Price(),
                  ));
                },
              ),
              ListTile(
                leading: const Icon(Icons.menu),
                title: const Text(
                  'Price+',
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: (context) => const PricePlus(),
                  ));
                },
              ),
              ListTile(
                leading: const Icon(Icons.menu),
                title: const Text(
                  'Graph',
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: (context) => const Graph(),
                  ));
                },
              ),
            ],
          ),
        ),
        body: Column(children: [
          const SizedBox(
            height: 20,
          ),
          Container(
            margin: const EdgeInsets.only(left: 10, bottom: 8, right: 10),
            padding: const EdgeInsets.only(right: 10),
            height: 200,
            decoration: BoxDecoration(
                color: Colors.grey.shade200,
                borderRadius: BorderRadius.circular(15)),
            child: Stack(
              children: [
                Row(
                  children: [
                    ClipRRect(
                      borderRadius: const BorderRadius.only(
                          topLeft: Radius.circular(10),
                          bottomLeft: Radius.circular(10)),
                      child: Image.asset(
                        'assets/images/calstobg.png',
                        width: 100,
                        height: 100,
                      ),
                    ),
                    const SizedBox(width: 20.0),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            'What is CALSTO?',
                            style: TextStyle(
                                color: Colors.black.withOpacity(0.7),
                                fontWeight: FontWeight.bold,
                                fontSize: 24),
                          ),
                          const SizedBox(height: 10.0),
                          Text(
                            'Calsto is a financial advisory app which contains a consolidated database of resources which helps to make an individual to make an informed decision.',
                            style: TextStyle(
                              color: Colors.black.withOpacity(0.6),
                              fontWeight: FontWeight.w600,
                              fontSize: 14.0,
                            ),
                          ),
                        ],
                      ),
                    )
                  ],
                ),
              ],
            ),
          ),
          Align(
              alignment: Alignment.center,
              child: SingleChildScrollView(
                  padding: const EdgeInsets.only(left: 20, right: 20),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: const [
                      SizedBox(
                        height: 40,
                      ),
                      Text(
                        "DISCLAIMER",
                        style: TextStyle(
                            decoration: TextDecoration.underline,
                            fontWeight: FontWeight.w500,
                            fontSize: 22,
                            color: Colors.red),
                        textAlign: TextAlign.center,
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Text(
                        "Every decision made by the individual is of his/her responsibility. Calsto will not be responsible for any loss happened during the course of that decision. Calsto only provides the resources. Calsto only helps to make the decision.",
                        style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w300,
                            color: Colors.white60),
                        textAlign: TextAlign.center,
                      ),
                      SizedBox(
                        height: 20,
                      ),
                    ],
                  )))
        ]));
  }
}
